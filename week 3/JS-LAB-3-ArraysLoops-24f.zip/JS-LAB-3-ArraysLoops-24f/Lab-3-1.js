//LAB 3 - ARRAYS & LOOPS - PART 1

//ARRAY OF FRUITS
let fruits = ["apple", "banana", "orange", "grape", "kiwi"];

//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert(fruits[2]);
